package edu.mum.cs.swe.finalProject.RentCar.service.PaymentInfoValidatorStrategy.strategy;

public interface CardcheckStrategies {
}
