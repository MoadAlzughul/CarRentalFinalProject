package edu.mum.cs.swe.finalProject.RentCar.model.user;

public enum  Role {
    ADMIN,CUSTOMER

}

