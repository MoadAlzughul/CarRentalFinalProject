package edu.mum.cs.swe.finalProject.RentCar.service;

public interface IPaymentVerifier {

}
